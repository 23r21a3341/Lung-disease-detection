"""
Lung Disease Detection - Flask Backend
Team: Prasad, N. Adithya, P. Sharath Chandra
Guide: Mrs. D. Nilima
"""

import os, io, base64
import numpy as np
from flask import Flask, request, jsonify, render_template
from PIL import Image

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB
os.makedirs('uploads', exist_ok=True)

# ── Constants ─────────────────────────────────────────────────────────────────
MODEL_PATH = "model/vgg16_lung_disease.h5"

CLASS_NAMES = ["COVID-19", "Normal", "Pneumonia", "Tuberculosis"]

CLASS_INFO = {
    "COVID-19": {
        "color": "#ef4444",
        "description": "Bilateral ground-glass opacities, often peripheral and basal-predominant.",
        "recommendation": "Immediate isolation and PCR confirmation. Monitor O₂ saturation.",
        "severity": "high"
    },
    "Normal": {
        "color": "#22c55e",
        "description": "No significant radiological abnormality. Lung fields appear clear.",
        "recommendation": "No immediate intervention required. Routine follow-up as needed.",
        "severity": "low"
    },
    "Pneumonia": {
        "color": "#f97316",
        "description": "Consolidation or infiltrates indicative of bacterial or viral pneumonia.",
        "recommendation": "Antibiotic therapy and supportive care. Culture and sensitivity recommended.",
        "severity": "medium"
    },
    "Tuberculosis": {
        "color": "#a855f7",
        "description": "Upper lobe infiltrates or cavitation consistent with pulmonary tuberculosis.",
        "recommendation": "Sputum AFB smear and culture. DOTS therapy initiation after confirmation.",
        "severity": "high"
    }
}

model = None


# ── Model ─────────────────────────────────────────────────────────────────────
def build_vgg16_model():
    import tensorflow as tf
    from tensorflow.keras.applications import VGG16
    from tensorflow.keras import layers, Model

    base = VGG16(weights='imagenet', include_top=False, input_shape=(224, 224, 3))
    base.trainable = False
    x = layers.GlobalAveragePooling2D()(base.output)
    x = layers.Dense(512, activation='relu')(x)
    x = layers.Dropout(0.5)(x)
    x = layers.Dense(256, activation='relu')(x)
    x = layers.Dropout(0.3)(x)
    out = layers.Dense(len(CLASS_NAMES), activation='softmax')(x)
    m = Model(inputs=base.input, outputs=out)
    m.compile(optimizer=tf.keras.optimizers.Adam(1e-4),
              loss='categorical_crossentropy', metrics=['accuracy'])
    return m


def load_model():
    global model
    try:
        import tensorflow as tf
        if os.path.exists(MODEL_PATH):
            model = tf.keras.models.load_model(MODEL_PATH)
            print(f"[✓] Model loaded: {MODEL_PATH}")
        else:
            print("[!] No saved model. Building VGG16 architecture (untrained).")
            model = build_vgg16_model()
    except ImportError:
        print("[!] TensorFlow not installed — DEMO mode active.")


def preprocess_image(img: Image.Image) -> np.ndarray:
    img = img.convert('RGB').resize((224, 224))
    arr = np.array(img, dtype=np.float32)
    arr[..., 0] -= 103.939
    arr[..., 1] -= 116.779
    arr[..., 2] -= 123.68
    return np.expand_dims(arr, 0)


def generate_gradcam(img_array, pred_idx):
    try:
        import tensorflow as tf, cv2
        grad_model = tf.keras.Model(
            inputs=model.inputs,
            outputs=[model.get_layer('block5_conv3').output, model.output]
        )
        with tf.GradientTape() as tape:
            conv_out, preds = grad_model(img_array)
            loss = preds[:, pred_idx]
        grads = tape.gradient(loss, conv_out)
        pooled = tf.reduce_mean(grads, axis=(0, 1, 2))
        cam = np.maximum(tf.reduce_sum(tf.multiply(pooled, conv_out[0]), axis=-1).numpy(), 0)
        if cam.max() > 0:
            cam /= cam.max()
        cam = cv2.resize(cam, (224, 224))
        heatmap = cv2.applyColorMap(np.uint8(255 * cam), cv2.COLORMAP_JET)
        orig = cv2.cvtColor(np.uint8(img_array[0] + [103.939, 116.779, 123.68]), cv2.COLOR_RGB2BGR)
        superimposed = cv2.addWeighted(orig, 0.6, heatmap, 0.4, 0)
        _, buf = cv2.imencode('.png', superimposed)
        return base64.b64encode(buf).decode()
    except Exception as e:
        print(f"[Grad-CAM] {e}")
        return None


def mock_prediction():
    idx = np.random.randint(len(CLASS_NAMES))
    raw = np.random.dirichlet(np.ones(len(CLASS_NAMES)) * 0.4)
    raw[idx] *= 3
    raw /= raw.sum()
    return raw.tolist()


# ── Routes ────────────────────────────────────────────────────────────────────
@app.route('/')
def index():
    return render_template('index.html')


@app.route('/predict', methods=['POST'])
def predict():
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400
    file = request.files['file']
    if not file.filename:
        return jsonify({'error': 'Empty filename'}), 400

    allowed = {'png', 'jpg', 'jpeg', 'bmp', 'tiff'}
    ext = file.filename.rsplit('.', 1)[-1].lower()
    if ext not in allowed:
        return jsonify({'error': f'Unsupported type: .{ext}'}), 400

    img_bytes = file.read()
    img = Image.open(io.BytesIO(img_bytes))

    buf = io.BytesIO()
    img.convert('RGB').save(buf, format='PNG')
    img_b64 = base64.b64encode(buf.getvalue()).decode()

    img_array = preprocess_image(img)
    if model is not None:
        preds = model.predict(img_array, verbose=0)[0].tolist()
    else:
        preds = mock_prediction()

    pred_idx = int(np.argmax(preds))
    pred_class = CLASS_NAMES[pred_idx]

    gradcam_b64 = generate_gradcam(img_array, pred_idx) if model is not None else None

    return jsonify({
        'prediction': pred_class,
        'confidence': round(preds[pred_idx] * 100, 2),
        'probabilities': {CLASS_NAMES[i]: round(p * 100, 2) for i, p in enumerate(preds)},
        'info': CLASS_INFO[pred_class],
        'image': img_b64,
        'gradcam': gradcam_b64,
        'demo_mode': model is None
    })


@app.route('/model-info')
def model_info():
    return jsonify({
        'architecture': 'VGG16 (Transfer Learning)',
        'classes': CLASS_NAMES,
        'input_shape': '224x224x3',
        'framework': 'TensorFlow / Keras',
        'loaded': model is not None
    })


if __name__ == '__main__':
    load_model()
    app.run(debug=True, host='0.0.0.0', port=5000)
