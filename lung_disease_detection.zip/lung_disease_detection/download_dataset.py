"""
download_dataset.py — Download chest X-ray dataset from Kaggle
Usage: python download_dataset.py

Requires: pip install kaggle
Setup: Place kaggle.json in ~/.kaggle/  (from Kaggle > Account > API)
"""

import os, subprocess, sys

DATASET = "tawsifurrahman/covid19-radiography-database"  # ~1.15 GB

def check_kaggle():
    try:
        import kaggle
        return True
    except ImportError:
        print("[!] kaggle not installed. Run: pip install kaggle")
        return False

def download():
    if not check_kaggle():
        sys.exit(1)

    kaggle_json = os.path.expanduser("~/.kaggle/kaggle.json")
    if not os.path.exists(kaggle_json):
        print("[!] kaggle.json not found.")
        print("    Go to https://www.kaggle.com/account → API → Create New Token")
        print(f"    Move the downloaded file to: {kaggle_json}")
        sys.exit(1)

    os.makedirs("raw_data", exist_ok=True)
    print(f"[*] Downloading dataset: {DATASET}")
    subprocess.run(["kaggle", "datasets", "download", "-d", DATASET, "-p", "raw_data", "--unzip"], check=True)
    print("[✓] Dataset downloaded to raw_data/")

    print("[*] Preparing train/val split...")
    prepare_split()


def prepare_split():
    """Organise downloaded images into dataset/train and dataset/val"""
    import shutil, random
    from pathlib import Path

    SRC = Path("raw_data")
    DST = Path("dataset")
    VAL_SPLIT = 0.2

    CLASS_MAP = {
        "COVID": "COVID-19",
        "Normal": "Normal",
        "Viral Pneumonia": "Pneumonia",
        "Lung_Opacity": "Pneumonia",   # treat as Pneumonia
        # Add more mappings if your dataset differs
    }

    for src_cls, dst_cls in CLASS_MAP.items():
        src_dir = SRC / src_cls / "images"
        if not src_dir.exists():
            src_dir = SRC / src_cls  # fallback
        if not src_dir.exists():
            print(f"[!] Skipping {src_cls} — not found")
            continue

        imgs = list(src_dir.glob("*.png")) + list(src_dir.glob("*.jpg"))
        random.shuffle(imgs)
        split = int(len(imgs) * (1 - VAL_SPLIT))

        for split_name, subset in [("train", imgs[:split]), ("val", imgs[split:])]:
            out = DST / split_name / dst_cls
            out.mkdir(parents=True, exist_ok=True)
            for img in subset:
                shutil.copy(img, out / img.name)
        print(f"[✓] {dst_cls}: {split} train, {len(imgs)-split} val")

    print("[✓] Dataset ready in dataset/")


if __name__ == "__main__":
    download()
