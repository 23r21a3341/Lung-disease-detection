# 🫁 PneumoScan — Lung Disease Detection
**Deep Learning Project using VGG16 + Grad-CAM**

> Team: Prasad · N. Adithya · P. Sharath Chandra  
> Guide: Mrs. D. Nilima

---

## 📁 Project Structure

```
lung_disease_detection/
├── app.py                  ← Flask web server (run this!)
├── train.py                ← Model training script
├── evaluate.py             ← Confusion matrix & metrics
├── download_dataset.py     ← Kaggle dataset downloader
├── requirements.txt        ← Python dependencies
├── templates/
│   └── index.html          ← Frontend UI (PneumoScan)
├── model/
│   └── vgg16_lung_disease.h5   ← Saved model (after training)
└── dataset/
    ├── train/
    │   ├── COVID-19/
    │   ├── Normal/
    │   ├── Pneumonia/
    │   └── Tuberculosis/
    └── val/
        └── ...
```

---

## 🚀 Quick Start (VSCode)

### 1. Open project in VSCode
```bash
cd lung_disease_detection
code .
```

### 2. Create a virtual environment
```bash
python -m venv venv

# Windows
venv\Scripts\activate

# Mac/Linux
source venv/bin/activate
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

> ⚡ **No GPU?** TensorFlow works on CPU too, just slower.  
> For GPU: install `tensorflow[and-cuda]` instead.

### 4. Run the app (Demo mode — no training needed)
```bash
python app.py
```
Open: **http://localhost:5000**

Upload any chest X-ray image to test the UI.  
In demo mode, predictions are random placeholders.

---

## 🏋️ Training the Model

### Step 1: Get the dataset

**Option A — Kaggle (Recommended)**
```bash
pip install kaggle
# Place kaggle.json in ~/.kaggle/
python download_dataset.py
```

**Option B — Manual**  
Download from: https://www.kaggle.com/datasets/tawsifurrahman/covid19-radiography-database  
Unzip and run: `python download_dataset.py` (only the split step)

**Option C — NIH ChestX-ray14**  
https://nihcc.app.box.com/v/ChestXray-NIHCC

### Step 2: Train
```bash
python train.py --data_dir ./dataset --epochs 20
```
Best model saved to `model/vgg16_lung_disease.h5` automatically.

### Step 3: Evaluate
```bash
python evaluate.py --model model/vgg16_lung_disease.h5 --data_dir ./dataset
```
Outputs:
- Confusion matrix → `confusion_matrix.png`
- Classification report (precision, recall, F1)
- Macro AUC-ROC score

### Step 4: Run with trained model
```bash
python app.py
```
Now predictions are real!

---

## 🧠 Architecture

```
Input (224×224×3)
    ↓
VGG16 Base (ImageNet weights, frozen)
    ↓
GlobalAveragePooling2D
    ↓
Dense(512, ReLU) → Dropout(0.5)
    ↓
Dense(256, ReLU) → Dropout(0.3)
    ↓
Dense(4, Softmax)
    ↓
Output: [COVID-19, Normal, Pneumonia, Tuberculosis]
```

**Grad-CAM** highlights the regions the model focused on for its diagnosis.

---

## 🔧 VSCode Extensions (Recommended)

Install these for the best experience:
- **Python** (Microsoft)
- **Pylance**
- **Thunder Client** (test `/predict` API)
- **GitLens**

---

## 📊 Expected Performance (after training)

| Class | Precision | Recall | F1 |
|-------|-----------|--------|----|
| COVID-19 | ~94% | ~92% | ~93% |
| Normal | ~97% | ~98% | ~97% |
| Pneumonia | ~90% | ~91% | ~90% |
| Tuberculosis | ~93% | ~94% | ~93% |

*Actual results depend on dataset size and training epochs.*

---

## 🌐 API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | Web UI |
| `/predict` | POST | Upload image → get prediction |
| `/model-info` | GET | Model architecture info |

**Test with curl:**
```bash
curl -X POST -F "file=@chest_xray.png" http://localhost:5000/predict
```

---

## 📝 License
Academic project. For educational purposes only.  
**Not for clinical/medical use.**
