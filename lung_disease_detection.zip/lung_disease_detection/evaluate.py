"""
evaluate.py — Evaluate trained model with confusion matrix & classification report
Usage: python evaluate.py --model model/vgg16_lung_disease.h5 --data_dir ./dataset
"""

import argparse
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score
from sklearn.preprocessing import label_binarize

CLASS_NAMES = ["COVID-19", "Normal", "Pneumonia", "Tuberculosis"]


def evaluate(model_path, data_dir):
    model = tf.keras.models.load_model(model_path)
    print(f"[✓] Model loaded: {model_path}")

    val_gen = ImageDataGenerator(rescale=1. / 255).flow_from_directory(
        f"{data_dir}/val",
        target_size=(224, 224),
        batch_size=32,
        class_mode='categorical',
        classes=CLASS_NAMES,
        shuffle=False
    )

    print("[*] Running predictions...")
    preds = model.predict(val_gen, verbose=1)
    y_pred = np.argmax(preds, axis=1)
    y_true = val_gen.classes

    # Classification report
    print("\nClassification Report:")
    print(classification_report(y_true, y_pred, target_names=CLASS_NAMES))

    # Confusion matrix
    cm = confusion_matrix(y_true, y_pred)
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                xticklabels=CLASS_NAMES, yticklabels=CLASS_NAMES)
    plt.title('Confusion Matrix — Lung Disease Detection')
    plt.ylabel('True Label')
    plt.xlabel('Predicted Label')
    plt.tight_layout()
    plt.savefig('confusion_matrix.png', dpi=150)
    print("[✓] Confusion matrix saved: confusion_matrix.png")

    # AUC-ROC
    y_true_bin = label_binarize(y_true, classes=list(range(len(CLASS_NAMES))))
    auc = roc_auc_score(y_true_bin, preds, multi_class='ovr', average='macro')
    print(f"\n[✓] Macro AUC-ROC: {auc:.4f}")


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', default='model/vgg16_lung_disease.h5')
    parser.add_argument('--data_dir', default='./dataset')
    args = parser.parse_args()
    evaluate(args.model, args.data_dir)
