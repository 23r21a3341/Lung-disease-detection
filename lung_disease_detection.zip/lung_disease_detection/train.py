"""
train.py — Train VGG16 on chest X-ray dataset
Usage: python train.py --data_dir ./dataset --epochs 20

Dataset folder structure expected:
  dataset/
    train/
      COVID-19/   *.jpg ...
      Normal/
      Pneumonia/
      Tuberculosis/
    val/
      COVID-19/
      ...
"""

import argparse
import os
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.callbacks import (ModelCheckpoint, EarlyStopping,
                                        ReduceLROnPlateau, TensorBoard)
import matplotlib.pyplot as plt

CLASS_NAMES = ["COVID-19", "Normal", "Pneumonia", "Tuberculosis"]
IMG_SIZE = (224, 224)
BATCH_SIZE = 32


def build_model():
    from tensorflow.keras.applications import VGG16
    from tensorflow.keras import layers, Model

    base = VGG16(weights='imagenet', include_top=False, input_shape=(224, 224, 3))

    # Unfreeze last few layers for fine-tuning
    for layer in base.layers[:-4]:
        layer.trainable = False
    for layer in base.layers[-4:]:
        layer.trainable = True

    x = layers.GlobalAveragePooling2D()(base.output)
    x = layers.BatchNormalization()(x)
    x = layers.Dense(512, activation='relu')(x)
    x = layers.Dropout(0.5)(x)
    x = layers.Dense(256, activation='relu')(x)
    x = layers.Dropout(0.3)(x)
    out = layers.Dense(len(CLASS_NAMES), activation='softmax')(x)

    model = Model(inputs=base.input, outputs=out)
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=1e-4),
        loss='categorical_crossentropy',
        metrics=['accuracy',
                 tf.keras.metrics.AUC(name='auc'),
                 tf.keras.metrics.Precision(name='precision'),
                 tf.keras.metrics.Recall(name='recall')]
    )
    return model


def get_generators(data_dir):
    train_aug = ImageDataGenerator(
        rescale=1. / 255,
        rotation_range=15,
        width_shift_range=0.1,
        height_shift_range=0.1,
        shear_range=0.1,
        zoom_range=0.1,
        horizontal_flip=True,
        fill_mode='nearest'
    )
    val_aug = ImageDataGenerator(rescale=1. / 255)

    train_gen = train_aug.flow_from_directory(
        os.path.join(data_dir, 'train'),
        target_size=IMG_SIZE,
        batch_size=BATCH_SIZE,
        class_mode='categorical',
        classes=CLASS_NAMES
    )
    val_gen = val_aug.flow_from_directory(
        os.path.join(data_dir, 'val'),
        target_size=IMG_SIZE,
        batch_size=BATCH_SIZE,
        class_mode='categorical',
        classes=CLASS_NAMES,
        shuffle=False
    )
    return train_gen, val_gen


def plot_history(history, save_path='training_curves.png'):
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    axes[0].plot(history.history['accuracy'], label='Train Acc')
    axes[0].plot(history.history['val_accuracy'], label='Val Acc')
    axes[0].set_title('Accuracy'), axes[0].legend()
    axes[1].plot(history.history['loss'], label='Train Loss')
    axes[1].plot(history.history['val_loss'], label='Val Loss')
    axes[1].set_title('Loss'), axes[1].legend()
    plt.tight_layout()
    plt.savefig(save_path)
    print(f"[✓] Training curves saved: {save_path}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_dir', default='./dataset', help='Path to dataset')
    parser.add_argument('--epochs', type=int, default=20)
    parser.add_argument('--output', default='model/vgg16_lung_disease.h5')
    args = parser.parse_args()

    os.makedirs(os.path.dirname(args.output), exist_ok=True)

    print("[*] Loading data generators...")
    train_gen, val_gen = get_generators(args.data_dir)

    print("[*] Building VGG16 model...")
    model = build_model()
    model.summary()

    callbacks = [
        ModelCheckpoint(args.output, save_best_only=True, monitor='val_accuracy', verbose=1),
        EarlyStopping(patience=5, restore_best_weights=True, verbose=1),
        ReduceLROnPlateau(factor=0.5, patience=3, verbose=1),
        TensorBoard(log_dir='logs')
    ]

    print(f"[*] Training for {args.epochs} epochs...")
    history = model.fit(
        train_gen,
        validation_data=val_gen,
        epochs=args.epochs,
        callbacks=callbacks
    )

    plot_history(history)

    # Final evaluation
    print("\n[*] Final Evaluation:")
    results = model.evaluate(val_gen, verbose=1)
    for name, val in zip(model.metrics_names, results):
        print(f"  {name}: {val:.4f}")

    print(f"\n[✓] Model saved to: {args.output}")


if __name__ == '__main__':
    main()
